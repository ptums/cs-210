#!/bin/bash

g++ main.cpp CurrentInvestment.h CurrentInvestment.cpp -o main

//
// Created by peter tumulty on 7/12/22.
//

#ifndef AIRGEADBANKINGAPP_PRINTHEADERMESSAGE_H
#define AIRGEADBANKINGAPP_PRINTHEADERMESSAGE_H

void printHeaderMessage(float i = 0, float m = 0, int a = 0, int n = 0);

#endif //AIRGEADBANKINGAPP_PRINTHEADERMESSAGE_H

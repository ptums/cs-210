//
// Created by peter tumulty on 7/12/22.
//

#ifndef AIRGEADBANKINGAPP_ANNUALBALANCE_H
#define AIRGEADBANKINGAPP_ANNUALBALANCE_H
void annualBalance(float initialInvestment, float monthlyDeposit, float annualInterest, int numberOfYears, bool showMonthlyDeposit);

#endif //AIRGEADBANKINGAPP_ANNUALBALANCE_H

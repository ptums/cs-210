//
// Created by peter tumulty on 7/12/22.
//

#ifndef AIRGEADBANKINGAPP_CHARTOSTRING_H
#define AIRGEADBANKINGAPP_CHARTOSTRING_H
#include <iostream>
using namespace std;

string charToString(size_t n, char c);

#endif //AIRGEADBANKINGAPP_CHARTOSTRING_H

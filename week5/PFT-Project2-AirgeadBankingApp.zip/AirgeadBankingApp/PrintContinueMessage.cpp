#include <iostream>
using namespace std;

void printContinueMessage() {
   cout << "Press any key to continue . . ." << endl;
   cin.ignore();
   cin.get();
}
